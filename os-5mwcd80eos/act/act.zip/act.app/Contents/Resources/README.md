put Inter-Regular.ttf, Inter-Medium.ttf and Inter-SemiBold.ttf here and run `xcodegen generate`.

every font file in this folder is copied into the app and the five plugins and registered when a panel loads.
until the files are here, the panel falls back to Arial, the second face in the all inc. stack.
